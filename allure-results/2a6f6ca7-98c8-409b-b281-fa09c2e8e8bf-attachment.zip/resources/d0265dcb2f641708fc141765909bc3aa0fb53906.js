/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'text!js-translation.json'
], function (dict) {
    'use strict';

    return JSON.parse(dict);
});
